#ifndef AUDIODMA_H
#define AUDIODMA_H

#include <stdint.h>

void audioInit(void);
void audioSchedule(void);

#endif
