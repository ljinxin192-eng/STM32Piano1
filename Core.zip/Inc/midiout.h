#ifndef MIDIOUT_H
#define MIDIOUT_H

void midiout(int note);

#endif