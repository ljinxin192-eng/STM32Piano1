#include "midiout.h"

void midiout(int note)
{
	
}